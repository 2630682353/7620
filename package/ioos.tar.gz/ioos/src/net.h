#ifndef _http_net_h_
#define _http_net_h_
int tcp_connect(const char *host,const char *serv);
#endif
